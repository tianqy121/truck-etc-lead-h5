import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const leads = sqliteTable("truck_etc_leads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  leadNo: text("lead_no").notNull().unique(),
  industry: text("industry").notNull(),
  vehicleCount: text("vehicle_count").notNull(),
  contactName: text("contact_name").notNull(),
  phone: text("phone").notNull(),
  source: text("source").notNull().default("企微货车ETC H5"),
  status: text("status").notNull().default("待联系"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
