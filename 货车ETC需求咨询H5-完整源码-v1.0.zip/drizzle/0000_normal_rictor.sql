CREATE TABLE `truck_etc_leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_no` text NOT NULL,
	`industry` text NOT NULL,
	`vehicle_count` text NOT NULL,
	`contact_name` text NOT NULL,
	`phone` text NOT NULL,
	`source` text DEFAULT '企微货车ETC H5' NOT NULL,
	`status` text DEFAULT '待联系' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `truck_etc_leads_lead_no_unique` ON `truck_etc_leads` (`lead_no`);