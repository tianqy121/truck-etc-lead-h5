import { desc, getTableColumns } from "drizzle-orm";
import { getDb } from "../../../../db";
import { leads } from "../../../../db/schema";
import { getChatGPTUser } from "../../../chatgpt-auth";

const csvCell = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;

export async function GET(request: Request) {
  if (!(await getChatGPTUser())) return Response.json({ error: "请先登录管理后台。" }, { status: 401 });
  try {
    const url = new URL(request.url);
    const status = url.searchParams.get("status")?.trim() || "";
    const industry = url.searchParams.get("industry")?.trim() || "";
    const keyword = url.searchParams.get("q")?.trim() || "";
    const db = await getDb();
    const rows = await db.select(getTableColumns(leads)).from(leads).orderBy(desc(leads.createdAt));
    const filtered = rows.filter((lead) => (!status || status === "全部" || lead.status === status) && (!industry || industry === "全部" || lead.industry === industry) && (!keyword || [lead.leadNo, lead.contactName, lead.phone].some((value) => value.includes(keyword))));
    const header = ["线索编号", "提交时间", "企业行业", "车辆数量", "联系人", "联系电话", "来源", "跟进状态"];
    const body = filtered.map((lead) => [lead.leadNo, lead.createdAt, lead.industry, lead.vehicleCount, lead.contactName, lead.phone, lead.source, lead.status].map(csvCell).join(","));
    const csv = "\uFEFF" + [header.map(csvCell).join(","), ...body].join("\r\n");
    return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="truck-etc-leads-${new Date().toISOString().slice(0, 10)}.csv"`, "Cache-Control": "no-store" } });
  } catch { return Response.json({ error: "导出失败，请稍后重试。" }, { status: 500 }); }
}
