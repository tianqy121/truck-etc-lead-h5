import { desc, eq, like, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { leads } from "../../../db/schema";
import { getChatGPTUser } from "../../chatgpt-auth";

const industries = new Set(["物流/货运", "冷链运输", "制造业配送", "危化品运输", "其他"]);
const vehicleCounts = new Set(["1—5辆", "6—20辆", "21—50辆", "50辆以上"]);

function clean(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "Unexpected error";
  if (message.includes("no such table") || message.includes("truck_etc_leads")) {
    return "线索台账尚未初始化，请联系管理员完成数据库发布。";
  }
  return "提交失败，请稍后重试。";
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const industry = clean(body.industry);
    const vehicleCount = clean(body.vehicleCount);
    const contactName = clean(body.contactName);
    const phone = clean(body.phone);

    if (!industries.has(industry) || !vehicleCounts.has(vehicleCount) || !contactName) {
      return Response.json({ error: "请完整填写需求信息。" }, { status: 400 });
    }
    if (!/^1\d{10}$/.test(phone)) {
      return Response.json({ error: "请输入正确的手机号码。" }, { status: 400 });
    }

    const db = await getDb();
    const leadNo = `HC-${new Date().toISOString().slice(0, 7).replace("-", "")}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const [lead] = await db.insert(leads).values({ leadNo, industry, vehicleCount, contactName, phone }).returning({ leadNo: leads.leadNo });
    return Response.json({ success: true, leadNo: lead.leadNo }, { status: 201 });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

function adminResponse() {
  return Response.json({ error: "请先登录管理后台。" }, { status: 401 });
}

function buildCondition(status: string, industry: string, keyword: string) {
  const conditions = [];
  if (status && status !== "全部") conditions.push(eq(leads.status, status));
  if (industry && industry !== "全部") conditions.push(eq(leads.industry, industry));
  if (keyword) {
    const pattern = `%${keyword}%`;
    conditions.push(or(like(leads.leadNo, pattern), like(leads.contactName, pattern), like(leads.phone, pattern))!);
  }
  return conditions.length ? conditions.reduce((a, b) => or(a, b)!) : undefined;
}

export async function GET(request: Request) {
  if (!(await getChatGPTUser())) return adminResponse();
  try {
    const url = new URL(request.url);
    const db = await getDb();
    const condition = buildCondition(url.searchParams.get("status")?.trim() || "", url.searchParams.get("industry")?.trim() || "", url.searchParams.get("q")?.trim() || "");
    const rows = await db.select().from(leads).where(condition).orderBy(desc(leads.createdAt));
    return Response.json({ leads: rows });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!(await getChatGPTUser())) return adminResponse();
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const leadNo = clean(body.leadNo);
    const status = clean(body.status);
    if (!leadNo || !["待联系", "已联系", "意向明确", "已签约", "暂不办理"].includes(status)) return Response.json({ error: "状态信息不完整。" }, { status: 400 });
    const db = await getDb();
    await db.update(leads).set({ status }).where(eq(leads.leadNo, leadNo));
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}
